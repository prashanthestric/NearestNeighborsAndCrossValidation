package knnandkfoldcrossval;
import java.util.ArrayList;

/**
 * Class that consists of methods to get information from the data fetched from the input files
 * 
 * @author Prashanth Govindaraj
 */
public class DataProcessor {
	
	/**
	 * Returns the data in a structured format for processing
	 * 
	 * @param records unstructured data fetched from the file
	 */
	public ArrayList<TheDataModel> getDataTabulated(ArrayList<char[]> records){
		
			ArrayList<TheDataModel> tabulatedData=new ArrayList<TheDataModel>();
			char[] firstLine=records.get(0);
			int noOfRows=Character.getNumericValue(firstLine[0]);
			int noOfCols=Character.getNumericValue(firstLine[1]);
		
			for(int i=1;i<(noOfRows+1);i++){
				char[] row=records.get(i);
				for(int j=0;j<noOfCols;j++){
				
					tabulatedData.add(new TheDataModel(j, i-1, row[j]));
				
				}
			}
		
		return tabulatedData;
		
	}
	
	/**
	 * returns the number of rows of examples in the raster ordered input file
	 */
	public int getNoOfRows(ArrayList<char[]> records){
		char[] firstLine=records.get(0);
		return Character.getNumericValue(firstLine[0]);
	}
	
	/**
	 * returns the number of columns of examples in the raster ordered input file
	 */
	public int getNoOfCols(ArrayList<char[]> records){
		char[] firstLine=records.get(0);
		return Character.getNumericValue(firstLine[1]);
	}
	
	/**
	 * calculates the index number of an instance (x1,x2)
	 */
	public int getIndexOfCoordinate(TheDataModel data,ArrayList<char[]> records){
		return ((data.getX2()*getNoOfCols(records))+data.getX1());
	}
	
	/**
	 * returns k value for cross validation
	 */
	public int getKOfCV(ArrayList<char[]> records){
		char[] firstLine=records.get(0);
		return Character.getNumericValue(firstLine[0]);
	}
	
	/**
	 * returns number of examples for cross validation
	 */
	public int getNoOfExamplesCV(ArrayList<char[]> records){
		char[] firstLine=records.get(0);
		return Character.getNumericValue(firstLine[1]);
	}
	
	/**
	 * returns number of permutations for cross validation
	 */
	public int getNoOfPermutationsCV(ArrayList<char[]> records){
		char[] firstLine=records.get(0);
		return Character.getNumericValue(firstLine[2]);
	}
	
	/**
	 * returns an Arraylist that contains only classified data(training examples)
	 * 
	 * @param tabulatedData An arrayList of all data, both classified and unclassified
	 * @return classifiedData an ArrayList that contains only classified data
	 */
	public ArrayList<TheDataModel> getClassifiedData(ArrayList<TheDataModel> tabulatedData){
		
		ArrayList<TheDataModel> classifiedData=new ArrayList<TheDataModel>();
		for(int i=0;i<tabulatedData.size();i++){
			if(tabulatedData.get(i).getY()!='.'){
				classifiedData.add(tabulatedData.get(i));
			}			
		}
		return classifiedData;
		
	}
	
	/**
	 * returns an Arraylist that contains only unclassified data.
	 * 
	 * @param tabulatedData An arrayList of all data, both classified and unclassified
	 * @return classifiedData an ArrayList that contains only unclassified data
	 */
	public ArrayList<TheDataModel> getUnclassifiedData(ArrayList<TheDataModel> tabulatedData){
		
		ArrayList<TheDataModel> unclassifiedData=new ArrayList<TheDataModel>();
		for(int i=0;i<tabulatedData.size();i++){
			if(tabulatedData.get(i).getY()=='.'){
				unclassifiedData.add(tabulatedData.get(i));
			}			
		}
		return unclassifiedData;
		
	}


}
