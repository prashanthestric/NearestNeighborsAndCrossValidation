package knnandkfoldcrossval;

/**
 * Data model for an instance (x1,x2,y)
 * 
 * @author Prashanth Govindaraj
 */
public class TheDataModel {
	
	int x1,x2;
	char y;
	
	public TheDataModel(int xOne,int xTwo){
		
		x1=xOne;
		x2=xTwo;
		y='.';
		
	}
	public TheDataModel(int xOne,int xTwo,char why)
	{
		
		x1=xOne;
		x2=xTwo;
		y=why;
		
	}
	
	public int getX1() {
		return x1;
	}
	public int getX2() {
		return x2;
	}
	public char getY() {
		return y;
	}
	public void setY(char y) {
		this.y = y;
	}

}
